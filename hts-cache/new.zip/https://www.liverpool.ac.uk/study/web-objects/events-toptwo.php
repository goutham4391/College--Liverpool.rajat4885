<!doctype html>

<body>

<h2><a href="//www.liverpool.ac.uk/events/">Events</a></h2><div class="event clearfix"><a href="/events/event/?eventid=102457" style="text-decoration: none;"><img src='https://www.liverpool.ac.uk/tulip-assets/events-images/633adb26a0835.jpg' alt='' /><article class='event-details'>
		<div class='date-time'>15 November  2022</div>
		<h2>Heseltine Institute Lecture</h2></article>
		</a></div><div class="event clearfix"><a href="/events/event/?eventid=102455" style="text-decoration: none;"><img src='https://www.liverpool.ac.uk/tulip-assets/events-images/634ebae59d3af.png' alt='' /><article class='event-details'>
		<div class='date-time'>27 October   2022</div>
		<h2>Bringing the World to Liverpool with Dr Peter Milner</h2></article>
		</a></div>
</body>
</html>